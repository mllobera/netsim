# Top level for Network Simulation package
name = 'netsim'
version = '0.0.1'

# from netsim.simulate import *