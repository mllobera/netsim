# Top level for Network Simulation package
__name___ = 'netsim'
__version__ = '0.0.1'

# from netsim.simulate import *